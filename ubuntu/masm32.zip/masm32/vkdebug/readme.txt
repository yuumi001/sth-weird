VKDEBUG v1.1, September 2002.

DESCRIPTION

VKDEBUG is a debugging tool for the MASM32 package. For more information
see dbgwin.hlp

REQUIRMENTS

1. MASM32 v7
2. Windows 9x, Windows 2000/XP

INSTALLATION

1. Copy debug.inc to \masm32\include
2. Copy debug.lib to \masm32\lib
3. Copy dbgwin.exe to \masm32\bin
4. Copy dbgwin.hlp to \masm32\help

or run setup.bat

FEEDBACK

mailto:vkim@aport2000.ru
http://www.wasm.ru
