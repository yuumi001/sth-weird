1.  Please execute make.bat to compile the demo program with debugging 
    options. 

2.  Under Win9x you have to place dbghelp.dll from
    [DISK]:\MASM32\VKDEBUG\EXTRA\DBGHELP\ into [DISK]:\WINDOWS\SYSTEM\.