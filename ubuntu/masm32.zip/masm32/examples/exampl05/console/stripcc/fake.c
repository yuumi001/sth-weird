This file has both C and C++ comments
Do not attempt to build this file with a C compiler

C code;      // C++ comment
more C code; /* ------------------ old style C comment ------------
-------------*/
last C code; // another C++ comment
